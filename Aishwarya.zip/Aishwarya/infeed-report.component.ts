import { DatePipe, formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Workbook } from 'exceljs';
import * as  fileServer from 'file-saver'
import { InfeedMissionRuntimeDetailsModel } from 'src/app/model/InfeedMissionRuntimeDetails.model';
import { MasterAreaDetailsModel } from 'src/app/model/masterAreaDetails.model';
import { MasterFloorDetailsModel } from 'src/app/model/masterFloorDetails.model';
import { MasterProductDetailsModel } from 'src/app/model/masterProductDetails.model';
import { MasterProductVariantDetailsModel } from 'src/app/model/masterProductVariantDetails.model';
import { MasterShiftDetailsModel } from 'src/app/model/masterShiftDetails.model';
import { InfeedMissionRuntimeDetailsService } from 'src/app/services/InfeedMissionRuntimeDetails.service';
import { MasterAreaDetailsService } from 'src/app/services/masterAreaDetails.service';
import { MasterFloorDetailsService } from 'src/app/services/masterFloorDetails.service';
import { MasterProductDetailsService } from 'src/app/services/masterProductDetails.service';
import { MasterProductVariantDetailsService } from 'src/app/services/masterProductVariantDetails.service';
import { MasterShiftDetailsService } from 'src/app/services/masterShiftDetails.service';

@Component({
  selector: 'app-infeed-report',
  templateUrl: './infeed-report.component.html',
  styleUrls: ['./infeed-report.component.css']
})
export class InfeedMissionRuntimeDetailsComponent implements OnInit {
  infeedMissionReportDtOptions: DataTables.Settings = {};
  infeedMissionRuntimeDetailsList: InfeedMissionRuntimeDetailsModel[] = [];

  loadingSideInfeedMissionList: InfeedMissionRuntimeDetailsModel[] = [];
  emptyPalletInfeedList: InfeedMissionRuntimeDetailsModel[] = [];
  filledPalletList: InfeedMissionRuntimeDetailsModel[] = [];
  area1InfeedList: InfeedMissionRuntimeDetailsModel[] = [];
  area2InfeedList: InfeedMissionRuntimeDetailsModel[] = [];


  selectedPalletCodeValue!: string;
  skuCode!: string;
  skuName!: string;
  batchNo!: string;
  prodOrderNo!: string

  //Fetching ProductName
  productNameDropDownList: MasterProductDetailsModel[] = [];
  productName!: string;

  //Fetching Shift Name
  shiftNameDropDownList: MasterShiftDetailsModel[] = [];
  selectedShiftName!: string;

  //Fetching Shift Name
  productVariantCodeDropDownList: MasterProductVariantDetailsModel[] = [];
  selectedProductVariantCode!: string;
  selectedProductVarientName!: string;

  //Fetching Floor Name
  floorDropDownList: MasterFloorDetailsModel[] = [];
  selectedFloor!: string;

  //Fetching Area Name
  areaDropDownList: MasterAreaDetailsModel[] = [];

  selectedArea!: string;

  shiftName!: string;
  productVariantCode!: string
  batchNumber!: string
  modelNumber!: string
  floorName!: string
  areaName!: string
  emptyPalletCount!: number;
  filledpalletCount!: number;
  area1InfeedCount!: number;
  area2InfeedCount!: number;
  totalInfeedCount!: number;
  a1LoadedEngineCount!: number;
  a2LoadedEngineCount!: number;
  selectedInfeedMissionStatus!: string
  infeedMissionCdatetimeStart!: string
  infeedMissionCdatetimeEnd!: string
  toDisplayFilter = false;
  disableSearchButton: boolean = false;
  disableDateTime: boolean = true;
  missionRuntimeInfeedStartDate!: string;
  missionRuntimeInfeedStatus!: string;
  missionRuntimeInfeedEndDate!: string;
  missionRuntimeInfeedStartTime!: string;
  missionRuntimeInfeedEndTime!: string;
  palletCode!: string;
  Quantity!: string;
  missionRuntimeInfeedStartDateFormatted!: string;
  missionRuntimeInfeedEndDateFormatted!: string;




  constructor(
    private infeedMissionRuntimeDetailsService: InfeedMissionRuntimeDetailsService,
    //Fetching ProductName
    private masterProductDetailsService: MasterProductDetailsService,
    //Fetching Shift Name
    private masterShiftDetailsService: MasterShiftDetailsService,
    //Fetching product Varient Code
    private masterProductVariantDetailsService: MasterProductVariantDetailsService,
    //Fetching floor
    private masterFloorDetailsService: MasterFloorDetailsService,
    //Fetching area
    private masterAreaDetailsService: MasterAreaDetailsService,

    private datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    //On refresh or on opning of this page following data will be fetched 
    this.fetchAllInfeedRunTimeReportByCurrentDate();
    this.fetchAllInfeedMissionRuntimeDetails();
    this.fetchProductNameFromProductDetails();
    this.fetchShiftNameFromShiftDetails();
    this.fetchProductVariantCodeFromProductVariantDetails();
    this.fetchInfeedMissionRuntimeDetailsByFilters();
    this.fetchfloorDetails();
    this.fetchAreaDetails();
    //this. fetchEmptyAndFilledPalletCount();
    // this.fetchEmptyPalletCount();


    this.infeedMissionReportDtOptions = {
      // pagingType: 'full_numbers',
      // pageLength: 10,
      // serverSide: true,
      // processing: true,
      ajax: () => {
        this.fetchAllInfeedMissionRuntimeDetails();
      }
    }
  }

  public fetchAllInfeedMissionRuntimeDetails() {
    this.disableDateTime = true;
    this.disableSearchButton = false;
    this.infeedMissionRuntimeDetailsService.fetchAllInfeedMission().subscribe(
      infeedMissionRuntimeDetailsList => {
        $('#infeedMissionRuntimeDetailsId').DataTable().clear().destroy();
        this.infeedMissionRuntimeDetailsList = infeedMissionRuntimeDetailsList;

        $(function () {
          $("#infeedMissionRuntimeDetailsId").DataTable();
        });
      }
    )
  }





  fetchAllInfeedRunTimeReportByCurrentDate() {
    this.disableDateTime = true;
    this.disableSearchButton = false;
    this.infeedMissionRuntimeDetailsService.fetchAllInfeedMission().subscribe(
      infeedDetailsList => {
        $('#infeedMissionRuntimeDetailsId').DataTable().clear().destroy();

        this.infeedMissionRuntimeDetailsList = infeedDetailsList

        $(function () {

          $("#infeedMissionRuntimeDetailsId").DataTable();
        });
      
      }
    )
  }



  public fetchInfeedMissionRuntimeDetailsByFilters() {

    this.resetData();
   
    this.infeedMissionRuntimeDetailsService.fetchInfeedMissionRuntimeDetailsByFilters(
      this.missionRuntimeInfeedStartDate,
      this.missionRuntimeInfeedEndDate, this.missionRuntimeInfeedStartTime, this.missionRuntimeInfeedEndTime, this.productName,
      this.missionRuntimeInfeedStatus, this.skuCode, this.batchNo, this.palletCode,
      this.floorName, this.areaName).subscribe(
        infeedMissionRuntimeDetailsFilter => {

          console.log(" this.missionRuntimeInfeedStartDate::" + this.missionRuntimeInfeedStartDate)
          console.log(" this.missionRuntimeInfeedEndDate::" + this.missionRuntimeInfeedEndDate)


          $('#infeedMissionRuntimeDetailsId').DataTable().clear().destroy();
          // console.log(" missionRuntimeInfeedStartDate::"+this.missionRuntimeInfeedStartDate);
          // console.log(" missionRuntimeInfeedStartDate::"+this.missionRuntimeInfeedEndDate);
          // this.infeedMissionRuntimeDetailsList = infeedMissionRuntimeDetailsFilter;

          // this.loadingSideInfeedMissionList = this.infeedMissionRuntimeDetailsList.filter(loadedList => loadedList.palletStatusId == 1);
          // console.log("fddddddddddddd"+JSON.stringify(this.infeedMissionRuntimeDetailsList))

          $(function () {
            $("#infeedMissionRuntimeDetailsId").DataTable();
          });
          console.log("this.infeedMissionRuntimeDetailsList ::" + infeedMissionRuntimeDetailsFilter.length)
          this.infeedMissionRuntimeDetailsList = infeedMissionRuntimeDetailsFilter;
        });

  }


  //Fetching ProductName
  public fetchShiftNameFromShiftDetails() {
    this.masterShiftDetailsService.fetchShiftDetails().subscribe(
      shiftList => {
        this.shiftNameDropDownList = shiftList;
      });
  }

  public selectShiftNameChangeHandler(value: string) {
    this.selectedShiftName = value;
  }

  //Fetching ProductName
  public fetchProductNameFromProductDetails() {
    this.masterProductDetailsService.fetchAllProductDetailsList().subscribe(
      productList => {
        this.productNameDropDownList = productList;
      });
  }

  public selectProductNameChangeHandler(value: string) {
    this.productName = value;
  }

  public selectMissionRuntimeInfeedStatusChangeHandler(value: string) {
    this.productName = value;
  }

  public selectSkuCodeChangeHandler(value: string) {
    this.productName = value;
  }




  //Fetching ProductVarientCode
  public fetchProductVariantCodeFromProductVariantDetails() {
    this.masterProductVariantDetailsService.fetchAllData().subscribe(
      productVarientList => {
        this.productVariantCodeDropDownList = productVarientList;
      });
  }
  public selectProductVrientCodeChangeHandler(value: string) {
    this.selectedProductVariantCode = value;
  }

  public selectProductVarientNameChangeHandler(value: string) {
    this.selectedProductVarientName = value;
  }

  //Fetching Floor Details
  public fetchfloorDetails() {
    this.masterFloorDetailsService.fetchAllMasterFloorDetails().subscribe(
      floorList => {
        console.log("floorDropDownList::" + this.floorDropDownList)
        this.floorDropDownList = floorList;
      });
  }
  public selectFloorChangeHandler(value: string) {
    this.selectedFloor = value;
  }

  //Fetching Area Details
  public fetchAreaDetails() {
    this.masterAreaDetailsService.fetchAllMasterAreaDetails().subscribe(
      areaList => {
        this.areaDropDownList = areaList;
        console.log("arealist::" + this.areaDropDownList)
      });
  }
  public selectAreaChangeHandler(value: string) {
    this.selectedArea = value;
  }

  selectInfeedMissionStatusChangeHandler(value: string) {
    this.selectedInfeedMissionStatus = ''
    this.selectedInfeedMissionStatus = value

  }


  public dateTimeValidation() {

    if (this.missionRuntimeInfeedStartDate != null && (this.missionRuntimeInfeedEndDate == null || this.missionRuntimeInfeedEndDate == 'NA')) {
      this.disableDateTime = false;
      this.disableSearchButton = true;
    }

    else if (this.missionRuntimeInfeedStartDate != null && this.missionRuntimeInfeedEndDate != null && this.missionRuntimeInfeedStartDate <= this.missionRuntimeInfeedEndDate) {
      this.disableSearchButton = false;
    }

    else if (this.missionRuntimeInfeedStartDate != null && this.missionRuntimeInfeedEndDate != null && this.missionRuntimeInfeedStartDate < this.missionRuntimeInfeedEndDate) {
      this.disableSearchButton = false;
    }


    else if (this.missionRuntimeInfeedStartDate == this.missionRuntimeInfeedEndDate) {
      this.disableSearchButton = false;
    }

    else {
      this.disableSearchButton = true;
    }
  }


  resetData() {
    if (this.missionRuntimeInfeedStartDate == undefined || this.missionRuntimeInfeedStartDate == null) {
      this.missionRuntimeInfeedStartDate = "NA";
    }
  
    if (this.missionRuntimeInfeedEndDate == undefined || this.missionRuntimeInfeedEndDate == null) {
      this.missionRuntimeInfeedEndDate = "NA";
    }
    if (this.missionRuntimeInfeedStartTime == undefined || this.missionRuntimeInfeedStartTime == null) {
      this.missionRuntimeInfeedStartTime = "NA"
    }
    if (this.missionRuntimeInfeedEndTime == undefined || this.missionRuntimeInfeedEndTime == null) {
      this.missionRuntimeInfeedEndTime = "NA"
    }
    if (this.productName == undefined || this.productName == null) {
      this.productName = "NA"
    }
    if (this.missionRuntimeInfeedStatus == undefined || this.missionRuntimeInfeedStatus == null) {
      this.missionRuntimeInfeedStatus = "NA"
    }

    if (this.skuCode == undefined || this.skuCode == null) {
      this.skuCode = "NA"
    }
    if (this.batchNo == undefined || this.batchNo == null || this.batchNo.trim() == "") {
      this.batchNo = "NA"
    }
    if (this.palletCode == undefined || this.palletCode == null) {
      this.palletCode = "NA"
    }
    if (this.floorName == undefined || this.floorName == null) {
      this.floorName = "NA"
    }
    if (this.areaName == undefined || this.areaName == null) {
      this.areaName = "NA"
    }

    // if (this.infeedMissionCdatetimeStart == undefined || this.infeedMissionCdatetimeStart == null) {
    //   this.infeedMissionCdatetimeStart = "NA"
    // }
    // if (this.infeedMissionCdatetimeEnd == undefined || this.infeedMissionCdatetimeEnd == null) {
    //   this.infeedMissionCdatetimeEnd = "NA"
    // }
  }

  generateInfeedRunTimeExcelReport() {


    if (this.infeedMissionRuntimeDetailsList.length > 0) {


      //  const logoBase64Logo = "";
      const headerRowsCount = 6;


      const title = 'INFEED MISSION DETAILS REPORT' + "    " + formatDate(new Date(), 'dd-MMM-yyyy HH:mm:ss', 'en-US');

      // const title1 = 'A1 Loaded Engine'

      // const title2 = 'A2 Loaded Engine'

      // const title3 = 'Total Empty Pallet'

      // const title4 = 'Total Loaded Engine'


      const header = ["Sr.No", "Start Date", "End Date", "Start Time", "End Time", "Product name", "Status", "Sku Code", "Batch Number",
        "Floor Name", "Area Name", "Floor Name", "Area Name"];


      // Convert the id to sr.no
      for (let i = 0; i < this.infeedMissionRuntimeDetailsList.length; i++) {
        this.infeedMissionRuntimeDetailsList[i].infeedMissionId = (i + 1)
      }

      const data = this.infeedMissionRuntimeDetailsList.map((obj) =>
        Object.values({
          missionRuntimeInfeedStartDate: obj.missionRuntimeInfeedStartDate,
          missionRuntimeInfeedEndDate: obj.missionRuntimeInfeedEndDate,
          missionRuntimeInfeedStartTime: obj.missionRuntimeInfeedStartTime,
          missionRuntimeInfeedEndTime: obj.missionRuntimeInfeedEndTime,
          productName: obj.productName,
          missionRuntimeInfeedStatus: obj.batchNumber,
          skuCode: obj.skuCode,
          batchNumber: obj.batchNumber,
          palletCode: obj.palletCode,
          // weight: obj.weight,
          floorName: obj.floorName,
          areaName: obj.areaName,
          // location: obj.location,
          // floorName: obj.floorName,
          // areaName: obj.areaName,
          // rackName: obj.rackName,
          // positionName: obj.positionName,
          // shiftName: obj.shiftName,
          // infeedMissionStatus: obj.infeedMissionStatus,
          // infeedMissionCdatetime: obj.infeedMissionCDateTime,
          // infeedMissionStartDateTime: obj.infeedMissionStartDateTime,
          // infeedMissionEndDatetime: obj.infeedMissionEndDateTime

        }
        )
      );

      const emptypalletcount = this.emptyPalletCount;
      const a1outfeedcount = this.a1LoadedEngineCount;
      const a2outfeedcount = this.a2LoadedEngineCount;
      const totaloutfeed = this.totalInfeedCount;


      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet('Infeed Mission Data');

      // Add new row
      let titleRow = worksheet.addRow([title]);
      var titleRow1 = worksheet.addRow([]);

      var titleRow2 = worksheet.addRow([]);

      // Set font, size and style in title row.
      // titleRow.font = { name: 'Calibri', family: 4, size: 22, underline: 'double', bold: true };
      titleRow.font = { name: 'Calibri', family: 4, size: 22 };

      titleRow1.font = { name: 'Calibri', family: 4, size: 16 };

      titleRow2.font = { name: 'Calibri', family: 4, size: 16 };


      // Align the title in the center
      worksheet.getCell('A1').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('D2').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('D3').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('H2').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('H3').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('L2').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('L3').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('P2').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.getCell('P3').alignment = { vertical: 'middle', horizontal: 'center' };

      //Merge Cells
      worksheet.mergeCells(`A${titleRow.number}:R${titleRow.number}`);
      // worksheet.mergeCells("S1:S3");
      // worksheet.mergeCells(`D${titleRow1.number}:E${titleRow1.number}`);
      // worksheet.getCell('D2:E2').value = title1;
      // worksheet.mergeCells(`H${titleRow1.number}:J${titleRow1.number}`);
      // worksheet.getCell('H2:J2').value = title2;
      // worksheet.mergeCells(`L${titleRow1.number}:N${titleRow1.number}`);
      // worksheet.getCell('L2:N2').value = title4;
      // worksheet.mergeCells(`P${titleRow1.number}:Q${titleRow1.number}`);
      // worksheet.getCell('P2:Q2').value = title4;

      worksheet.mergeCells(`D${titleRow2.number}:E${titleRow2.number}`);
      worksheet.getCell('D3:E3').value = a1outfeedcount;
      worksheet.mergeCells(`H${titleRow2.number}:J${titleRow2.number}`);
      worksheet.getCell('H3:J3').value = a2outfeedcount;
      // worksheet.mergeCells(`L${titleRow2.number}:N${titleRow2.number}`);
      // worksheet.getCell('L3:N3').value = emptypalletcount;
      worksheet.mergeCells(`L${titleRow2.number}:N${titleRow2.number}`);
      worksheet.getCell('L3:N3').value = totaloutfeed;


      // Blank Row
      worksheet.addRow([]);

      //Add row with current date
      // let subTitleRow = worksheet.addRow(['Date & Time : ' + (new Date().toLocaleString())]);

      // Add Image
      // let logo = workbook.addImage({
      //   base64: logoBase64Logo,
      //   extension: 'png',
      // });
      // worksheet.addImage(logo, 'S1:S3');


      //Add Header Row
      let headerRow = worksheet.addRow(header);
      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: '4472C4' },

        }
        cell.font = {

          color: { argb: 'FFFFFF' },
          size: 12,
          bold: true,
        }
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      });


      // Add all data without formatting
      worksheet.addRows(data);

      // Used to delete the column
      // worksheet.spliceColumns(21, 10);
      // worksheet.spliceColumns(20,1);

      // To give the width to the column
      worksheet.getColumn(2).width = 15;
      worksheet.getColumn(3).width = 15;
      worksheet.getColumn(4).width = 20;
      worksheet.getColumn(5).width = 20;
      worksheet.getColumn(6).width = 15;
      worksheet.getColumn(7).width = 15;
      worksheet.getColumn(8).width = 15;
      worksheet.getColumn(9).width = 15;
      worksheet.getColumn(10).width = 15;
      worksheet.getColumn(11).width = 15;
      worksheet.getColumn(12).width = 15;
      worksheet.getColumn(13).width = 15;
      worksheet.getColumn(14).width = 15;
      worksheet.getColumn(15).width = 15;
      worksheet.getColumn(16).width = 15;
      worksheet.getColumn(17).width = 30;
      worksheet.getColumn(18).width = 30;
      worksheet.getColumn(19).width = 30;


      // worksheet.addRow([]);

      //Footer Row
      let footerRow = worksheet.addRow(['This is system generated excel sheet.']);
      footerRow.getCell(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'F1F5F9' }
      };
      footerRow.getCell(1).border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      // Align the footer in the center
      worksheet.getCell('A' + (data.length + headerRowsCount + 1)).alignment = { vertical: 'middle', horizontal: 'center' };
      // console.log(data.length + headerRowsCount + 1);

      //Merge Cells
      worksheet.mergeCells(`A${footerRow.number}:S${footerRow.number}`);

      // Save the file in Excel format
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

        // const fileName="ProdData"+(new Date().getDay())+(new Date().getMonth())+(new Date().getFullYear())+(new Date().getTime())+(new Date().getMinutes())+(new Date().getSeconds());


        const todayDate = new Date();
        console.log(todayDate);

        const fileName = "InfeedReport_" + (todayDate.getDate()) + (todayDate.getMonth() + 1) + (todayDate.getFullYear()) + (todayDate.getHours())
          + (todayDate.getMinutes()) + (todayDate.getSeconds());

        fileServer.saveAs(blob, fileName + '.xlsx');
      })



    }
    else {
      alert("Data is not available");
    }
  }

}




