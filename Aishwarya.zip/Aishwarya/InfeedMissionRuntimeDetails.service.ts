import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { InfeedMissionRuntimeDetailsModel } from "../model/InfeedMissionRuntimeDetails.model";
import { BASE_URL } from "../util/const";

@Injectable({
    providedIn:"root"
})
export class InfeedMissionRuntimeDetailsService{  

    

public fetchAllInfeedMissionRuntimeDetails(){
        return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}InfeedDetails/fetchAllInfeedMission`);
}
    
public fetchInfeedMissionRuntimeDetailsByFilters(missionRuntimeInfeedStartDate:string, missionRuntimeInfeedEndDate:string, missionRuntimeInfeedStartTime:string, missionRuntimeInfeedEndTime:string, productName:string, missionRuntimeInfeedStatus:string, 
    skuCode:string, batchNo:string, palletCode:string, floorName: string,areaName:string){
     // console.log("service");
    return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}InfeedDetails/searchAllInfeedMissionRuntimeDetails/${missionRuntimeInfeedStartDate}/${missionRuntimeInfeedEndDate}/${missionRuntimeInfeedStartTime}/${missionRuntimeInfeedEndTime}/${productName}/${missionRuntimeInfeedStatus}/${skuCode}/${batchNo}/${palletCode}/${floorName}/${areaName}`);
    // console.log("service");
}
constructor(
    private http:HttpClient){

}


public fetchAllInfeedMission(){

    
    return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}InfeedDetails/fetchAllByCurrentDate`);
}

// fetchByInfeedMissionCdatetimeBetween(infeedMissionCdatetimeStart:String, infeedMissionCdatetimeEnd:String){
//     return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}fetchByInfeedMissionCdatetimeBetween/${infeedMissionCdatetimeStart}/${infeedMissionCdatetimeEnd}`);
// }




public updateInfeedMissionRuntimeDetailsDetails(infeedMissionObj: InfeedMissionRuntimeDetailsModel) {

    return this.http.put<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}updateInfeedMissionRuntimeDetailsDetails`, infeedMissionObj)

}


public fetchFilledPalletCount(productVariantCode :string,palletStatusId : number){
    return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}fetchFilledPalletCount/${productVariantCode}/${palletStatusId}`);
}

public fetchEmptyPalletCount(productVariantCode :string,palletStatusId : number){
    return this.http.get<InfeedMissionRuntimeDetailsModel[]>(`${BASE_URL}fetchEmptyPalletCount/${productVariantCode}/${palletStatusId}`);
}

}